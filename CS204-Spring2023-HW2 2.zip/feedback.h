#ifndef _FEEDBACK_H
#define _FEEDBACK_H

#include <string>

using namespace std;

string get_the_feedback (string guess, int game_id);

#endif //_FEEDBACK_H